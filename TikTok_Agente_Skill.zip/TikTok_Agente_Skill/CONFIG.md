# Configuração do canal

Preenche o que souberes. Deixa em branco o que ainda não estiver decidido.

## Identidade
- Nome do canal:
- Tema/nicho:
- Público pretendido:
- Região/país do público:
- Idioma principal: Português
- Idioma secundário: Inglês
- Tom: claro, natural, interessante e honesto
- Objetivo: crescimento orgânico / TikTok Shop / afiliados / outro

## Conteúdo
- Formatos preferidos: vídeos curtos, listas, explicações, histórias, demonstrações originais
- Duração-alvo:
- Frequência desejada: até 3 vídeos por dia, se houver qualidade suficiente
- Pilares de conteúdo:
- Temas a evitar:
- Concorrentes/referências públicas (opcional):

## Produção
- Ferramenta de vídeo:
- Ferramenta de edição:
- Ferramenta de voz:
- Voz própria autorizada disponível? Sim / Não
- Prova de consentimento para voz de terceiros guardada fora deste repositório? Sim / Não
- Música e assets: apenas originais, licenciados ou autorizados

## Publicação
- Plataforma:
- Integração oficial/parceiro autorizado:
- Modo: RASCUNHO (predefinido) / publicação autorizada
- Aprovação humana necessária: Sim (predefinição)

**Nunca preencher aqui:** palavra-passe, código 2FA, cookie, token, chave privada, dados bancários ou códigos de recuperação.
