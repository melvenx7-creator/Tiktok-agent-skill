# Guia de instalação e primeiro uso

## 1. Preparação
- Descompacta o ZIP.
- Abre `CONFIG.md` e preenche apenas as informações não sensíveis.
- Não escrevas palavra-passe, códigos SMS, códigos 2FA, cookies ou tokens no ficheiro.

## 2. Importação por plataforma

### ChatGPT
Usa o repositório como material de referência num Projeto ou num fluxo personalizado que aceite ficheiros/instruções. A disponibilidade de criação e execução de skills depende das funcionalidades da tua conta e do produto. Um ZIP, por si só, não instala automaticamente 11 skills nativas.

### Claude
Se estiveres a usar uma funcionalidade de Skills que aceite pastas de skill, importa as pastas individuais com o respetivo `SKILL.md`, seguindo a interface e documentação atual do Claude. Se só aceitar ficheiros de conhecimento, carrega os documentos relevantes como conhecimento; isso não equivale a executar ferramentas.

### Gemini
Adiciona as instruções e ficheiros num Gem ou ambiente Gemini que aceite conhecimento/instruções. Para ações externas, configura extensões ou integrações compatíveis. A importação do ZIP não concede acesso à conta TikTok.

## 3. Primeiro teste
Pede:
> Lê o README, CONFIG e AGENTS. Faz uma auditoria do canal e prepara um plano de conteúdo de 7 dias. Não publiques nada.

Depois pede:
> Cria três ideias originais para o próximo dia, com roteiro, plano de cenas, narração e metadados. Guarda tudo como rascunho.

## 4. Ativar publicação
Só depois de testar:
- Confirma que a conta e região são elegíveis para a integração pretendida.
- Usa uma API oficial ou parceiro autorizado.
- Autoriza apenas os escopos necessários.
- Mantém aprovação humana antes de publicar, pelo menos durante os testes.
- Faz uma publicação de teste e confirma o resultado na própria conta.

## 5. Frequência
O calendário pode propor até três publicações por dia. Ajusta a frequência com base na qualidade, retenção, comentários, regras da plataforma e capacidade real de produção. Não publiques conteúdo fraco só para cumprir uma quota.
