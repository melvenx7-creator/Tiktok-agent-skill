# TikTok Agente Skill

**Sistema modular de apoio à pesquisa, planeamento, produção e gestão de conteúdo para TikTok.**

Este repositório contém 11 skills especializadas e um fluxo central de coordenação. Foi pensado para ser adaptado a assistentes como ChatGPT, Claude e Gemini, respeitando as capacidades e os formatos de importação de cada plataforma.

> **Importante:** carregar este ZIP não liga automaticamente uma conta TikTok, não cria vídeos por si só e não concede permissões de publicação. Cada plataforma tem o seu próprio processo de instalação e as integrações externas precisam de ser configuradas separadamente.

## As 11 skills

1. `01-orchestrator` — coordena o trabalho e verifica os resultados.
2. `02-niche-research` — pesquisa e compara nichos.
3. `03-trend-research` — identifica tendências e oportunidades atuais.
4. `04-viral-reference-analysis` — analisa referências públicas sem copiar conteúdos.
5. `05-scriptwriter` — cria roteiros e ganchos.
6. `06-production-planner` — transforma roteiros em planos de produção.
7. `07-video-editor` — cria instruções de edição e controlo de qualidade.
8. `08-voiceover` — prepara narrações em português e inglês.
9. `09-seo-metadata` — cria títulos, descrições, hashtags e chamadas para ação.
10. `10-scheduler-publisher` — organiza calendário e publicação por integrações autorizadas.
11. `11-analytics-optimizer` — interpreta métricas e recomenda experiências.

## Começar

1. Extrai o ZIP ou carrega-o na área de ficheiros/conhecimento do teu ambiente de IA.
2. Lê `SETUP.md` e `CONFIG.md`.
3. Preenche `CONFIG.md` com o tema do canal, público, idioma, região e limites.
4. Escolhe uma plataforma e segue o respetivo processo de importação. Não existe um formato ZIP universal que instale skills automaticamente em ChatGPT, Claude e Gemini.
5. Começa por pedir: **“Executa o fluxo de planeamento semanal do TikTok Agente Skill.”**
6. Antes de ativar qualquer publicação automática, testa o fluxo em modo de rascunho e confirma as permissões da integração oficial.

## Publicação e segurança

- Nunca coloques palavras-passe, códigos de autenticação ou cookies neste repositório, em prompts ou em ficheiros de configuração.
- Usa OAuth ou outro método oficial de autorização, com permissões mínimas e revogáveis.
- A publicação automática só deve ser ativada quando a API e a conta forem elegíveis e a integração estiver aprovada.
- O modo predefinido é **rascunho + aprovação humana**.
- Três vídeos por dia é uma meta de planeamento, não uma obrigação nem garantia de alcance.
- Não descarregues, clones ou voltes a publicar vídeos de terceiros sem autorização. Usa-os apenas como referência de formato/tema e cria material original.
- Confirma direitos de música, imagens, clips, marcas e vozes. A clonagem de voz exige consentimento explícito da pessoa.
- Não inventes características, resultados, preços, descontos, disponibilidade ou testemunhos de produtos.
- Cumpre as regras atuais do TikTok, TikTok Shop, publicidade, afiliados e legislação aplicável.

## Estrutura

```text
TikTok_Agente_Skill/
├── README.md
├── SETUP.md
├── CONFIG.md
├── AGENTS.md
├── manifest.json
├── skills/
│   ├── 01-orchestrator/SKILL.md
│   ├── 02-niche-research/SKILL.md
│   ├── 03-trend-research/SKILL.md
│   ├── 04-viral-reference-analysis/SKILL.md
│   ├── 05-scriptwriter/SKILL.md
│   ├── 06-production-planner/SKILL.md
│   ├── 07-video-editor/SKILL.md
│   ├── 08-voiceover/SKILL.md
│   ├── 09-seo-metadata/SKILL.md
│   ├── 10-scheduler-publisher/SKILL.md
│   └── 11-analytics-optimizer/SKILL.md
├── templates/
│   ├── content-calendar.csv
│   ├── video-brief.md
│   └── performance-log.csv
└── integrations/
    └── INTEGRATION_GUIDE.md
```

## Estado atual

O repositório fornece instruções, modelos e procedimentos. Para gerar ficheiros de vídeo, sintetizar áudio, consultar tendências em tempo real, agendar ou publicar, é necessário ligar ferramentas externas compatíveis. As skills não fingem ter executado ações quando não existe uma ferramenta ligada.
