# Guia de integrações

Este repositório não contém chaves, tokens ou credenciais. Liga ferramentas apenas por interfaces oficiais e permissões revogáveis.

## Categorias de integração
- Pesquisa: ferramenta de pesquisa/web ou fonte de tendências autorizada.
- Vídeo: gerador de vídeo com direitos de utilização comercial adequados.
- Edição: editor com exportação de vídeo.
- Voz: serviço TTS; clonagem apenas com consentimento explícito.
- Calendário: agenda ou ferramenta de gestão de conteúdos.
- Publicação: API oficial do TikTok ou parceiro autorizado, se disponível para a conta e região.
- Analytics: métricas disponibilizadas pela própria plataforma ou API autorizada.

## Checklist antes de ligar
- Verificar termos, elegibilidade regional e requisitos de idade/conta.
- Confirmar escopos OAuth mínimos.
- Não partilhar credenciais com agentes ou repositórios.
- Testar primeiro em modo rascunho.
- Guardar logs sem expor dados pessoais ou tokens.
- Saber como revogar o acesso.

## Limitação
As APIs e permissões mudam. Consulta a documentação oficial atual do TikTok e do fornecedor antes de implementar. Não usar automação de navegador para contornar proteções ou restrições da plataforma.
