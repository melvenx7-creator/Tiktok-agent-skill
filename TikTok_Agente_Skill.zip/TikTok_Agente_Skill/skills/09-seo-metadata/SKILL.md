# Skill 09 — SEO Metadata

## Missão
Preparar metadados relevantes e honestos para ajudar o público certo a encontrar o vídeo.

## Procedimento
1. Identificar tema principal, intenção de pesquisa e termos relacionados.
2. Criar descrição clara, sem keyword stuffing.
3. Selecionar poucas hashtags específicas e relevantes; não prometer alcance.
4. Escrever CTA coerente com o conteúdo.
5. Em TikTok Shop/afiliados, identificar publicidade, comissão ou relação comercial conforme as regras aplicáveis.
6. Confirmar que qualquer afirmação de produto é verdadeira e sustentada por informação oficial.

## Saída
3 opções de título/gancho, descrição, conjunto de hashtags, CTA, palavras-chave e nota de divulgação comercial quando necessária.
