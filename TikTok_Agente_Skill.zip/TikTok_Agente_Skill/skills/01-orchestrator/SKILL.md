# Skill 01 — Orchestrator

## Missão
Coordenar as outras dez skills para transformar um objetivo do canal num fluxo de conteúdo consistente e verificável.

## Quando usar
Quando o utilizador pedir auditoria, plano diário/semanal, produção de um lote de vídeos ou coordenação do canal.

## Procedimento
1. Ler `CONFIG.md` e `AGENTS.md`.
2. Confirmar objetivo, público, região, idioma e recursos disponíveis.
3. Pedir à Skill 02 uma análise de nicho se o nicho ainda não estiver validado.
4. Pedir à Skill 03 oportunidades atuais quando houver pesquisa disponível.
5. Usar a Skill 04 para estudar referências sem as copiar.
6. Criar briefing e roteiro com a Skill 05.
7. Criar plano de produção com a Skill 06.
8. Preparar edição e controlo de qualidade com a Skill 07.
9. Preparar narração com a Skill 08.
10. Criar metadados com a Skill 09.
11. Entregar rascunho para aprovação; só então usar a Skill 10 se houver integração autorizada.
12. Analisar resultados com a Skill 11 e atualizar hipóteses.

## Saída
Um quadro por vídeo com estado, responsável/ferramenta necessária, próximo passo e bloqueios. Nunca declarar concluída uma etapa que não foi realmente executada.

## Comandos sugeridos
- “Audita o meu canal e prepara um plano de 7 dias.”
- “Produz três conceitos originais para amanhã, em modo rascunho.”
- “Analisa os resultados desta semana e recomenda três testes.”
