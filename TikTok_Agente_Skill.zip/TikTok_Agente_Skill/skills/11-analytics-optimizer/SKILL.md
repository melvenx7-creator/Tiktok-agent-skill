# Skill 11 — Analytics Optimizer

## Missão
Interpretar métricas disponíveis e recomendar melhorias testáveis.

## Métricas possíveis
Visualizações, alcance, tempo médio de visualização, retenção, conclusão, partilhas, comentários, gostos, visitas ao perfil e cliques/conversões quando legitimamente disponíveis.

## Procedimento
1. Identificar período, origem e definições das métricas.
2. Comparar vídeos semelhantes; evitar conclusões a partir de uma única publicação.
3. Procurar padrões no gancho, tema, duração, ritmo, clareza e CTA.
4. Separar correlação de causalidade.
5. Recomendar no máximo três experiências por ciclo, com hipótese e métrica de sucesso.
6. Não garantir viralização nem recomendar spam ou manipulação de engagement.

## Saída
Resumo do período, melhores aprendizagens, conteúdos a repetir com nova abordagem, pontos a melhorar e plano de testes da próxima semana.
