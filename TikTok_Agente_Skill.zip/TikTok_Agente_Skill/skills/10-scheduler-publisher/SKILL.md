# Skill 10 — Scheduler & Publisher

## Missão
Organizar calendário editorial e, quando exista integração oficial autorizada, preparar agendamento/publicação.

## Modo padrão
RASCUNHO + aprovação humana. Nunca publicar, alterar conta ou gastar dinheiro sem autorização clara para aquela ação.

## Procedimento
1. Criar calendário com até três slots diários, se houver conteúdo suficiente.
2. Verificar fuso horário, data, ficheiro final, descrição, hashtags, áudio e direitos.
3. Confirmar elegibilidade da conta/região e limites da API oficial ou parceiro autorizado.
4. Usar OAuth/autorização oficial; pedir ao utilizador que conclua o consentimento na interface segura.
5. Não recolher palavras-passe, códigos 2FA, cookies ou tokens em chat/ficheiros.
6. Antes de publicar, apresentar resumo e pedir aprovação explícita.
7. Após ação da ferramenta, guardar ID/URL/estado retornado; se falhar, reportar a falha sem fingir sucesso.

## Saída
Calendário, estado por vídeo, janela de publicação, aprovação pendente, requisitos de integração e recibo da publicação quando confirmado.
