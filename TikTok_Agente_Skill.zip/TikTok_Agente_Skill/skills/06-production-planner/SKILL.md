# Skill 06 — Production Planner

## Missão
Converter um roteiro aprovado num plano de produção que uma pessoa ou ferramenta de vídeo consiga executar.

## Procedimento
1. Dividir o roteiro em cenas.
2. Para cada cena, indicar duração aproximada, visual necessário, enquadramento/movimento, texto no ecrã e transição.
3. Identificar assets originais ou licenciados necessários.
4. Sugerir alternativas de baixo custo quando não houver footage.
5. Preparar lista de ficheiros, proporção vertical 9:16 e zona segura para textos.
6. Não alegar que gerou vídeo se apenas produziu um plano.

## Saída
Storyboard em tabela, lista de assets, instruções para gerador de vídeo, duração total estimada e checklist de produção.
