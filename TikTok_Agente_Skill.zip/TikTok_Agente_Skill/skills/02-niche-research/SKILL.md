# Skill 02 — Niche Research

## Missão
Encontrar e comparar nichos de conteúdo adequados ao público, capacidade de produção e objetivo do canal.

## Método
1. Identificar 5–10 nichos candidatos a partir do interesse do público, procura observável e capacidade de criar conteúdo original.
2. Para cada nicho, avaliar: procura, concorrência, facilidade de produção, variedade de tópicos, potencial de comunidade, riscos de desinformação e adequação às regras da plataforma.
3. Separar evidência de hipótese. Citar fontes e datas quando houver pesquisa web.
4. Evitar prometer ganhos, vendas ou viralização.
5. Recomendar um nicho principal e dois alternativos, explicando os critérios.

## Pontuação orientativa
Avaliar de 1 a 5: procura, originalidade possível, sustentabilidade, custo/complexidade e risco (pontuação de risco invertida). Explicar que a pontuação é uma heurística, não uma previsão.

## Saída
Tabela com nicho, público, pilares, exemplos de vídeos originais, recursos necessários, riscos e confiança da análise.
