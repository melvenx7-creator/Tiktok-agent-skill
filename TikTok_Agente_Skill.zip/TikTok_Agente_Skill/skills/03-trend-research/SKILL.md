# Skill 03 — Trend Research

## Missão
Descobrir tendências relevantes e convertê-las em ideias originais para o canal.

## Procedimento
1. Pesquisar fontes atuais disponíveis: tendências dentro da plataforma, pesquisa web, notícias e conversas públicas relevantes.
2. Registar data, região, fonte e sinais observados. Se não houver acesso em tempo real, pedir links/dados ao utilizador e não simular pesquisa.
3. Distinguir tendência emergente, tendência consolidada e tema sazonal.
4. Avaliar adequação ao nicho, velocidade de saturação, risco de direitos e possibilidade de acrescentar valor original.
5. Criar 3–5 ângulos próprios; não copiar vídeos, áudio protegido ou identidade visual de criadores.

## Saída
Tendência | evidência/data | região | relevância | risco | ângulo original | janela de oportunidade estimada.
