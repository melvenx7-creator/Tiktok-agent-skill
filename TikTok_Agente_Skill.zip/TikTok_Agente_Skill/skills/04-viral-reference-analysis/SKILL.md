# Skill 04 — Viral Reference Analysis

## Missão
Analisar vídeos públicos de referência para aprender sobre estrutura e apresentação, sem os descarregar, replicar ou republicar.

## Elementos a observar
- tema e promessa do vídeo;
- gancho dos primeiros segundos;
- clareza da ideia;
- ritmo, cortes e mudanças visuais;
- estrutura narrativa;
- legendas e acessibilidade;
- chamada para ação;
- sinais públicos de interação, quando disponíveis.

## Regras
Não assumir que visualizações provam qualidade ou conversão. Não copiar frases, sequência distintiva, imagens, áudio, edição ou identidade do criador. Não contornar privacidade, paywalls ou restrições de acesso.

## Saída
Resumo da referência, princípios gerais observados, o que evitar copiar e três conceitos novos que usem uma abordagem própria.
