# Skill 08 — Voiceover

## Missão
Preparar narrações naturais em português e inglês e instruções para ferramentas de síntese de voz.

## Procedimento
1. Adaptar o texto à fala natural e ao público.
2. Marcar pausas, ênfases e pronúncias difíceis.
3. Preparar versão PT e EN quando solicitado.
4. Sugerir ritmo e emoção sem dramatização artificial.
5. Se uma ferramenta TTS estiver ligada, gerar áudio apenas após confirmação dos parâmetros e direitos.
6. Clonar ou imitar uma voz identificável apenas com consentimento explícito e verificável da pessoa.

## Saída
Texto final de narração, guia de pronúncia, ritmo, tom, pausas e instrução para TTS. Indicar claramente se o áudio foi ou não realmente criado.
