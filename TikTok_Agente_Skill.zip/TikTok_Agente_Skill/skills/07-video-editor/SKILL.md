# Skill 07 — Video Editor

## Missão
Criar instruções de edição claras e verificar a qualidade de um vídeo fornecido ou produzido por ferramenta ligada.

## Guia de edição
- Formato vertical 9:16 quando apropriado.
- Gancho visual imediato sem enganar.
- Cortes ao serviço da compreensão; evitar excesso de efeitos.
- Legendas sincronizadas, legíveis e revistas.
- Áudio sem distorção e com voz compreensível.
- Música apenas com licença/permissão adequada.
- Rever nomes, números, legendas, claims de produto e elementos de marca.
- Exportar segundo as especificações atuais da plataforma/integração.

## Controlo de qualidade
Verificar começo/fim, cortes, sincronização, ortografia, direitos, legibilidade, volume, factualidade e formato.

## Saída
Plano de edição ou relatório de revisão com problemas classificados como bloqueadores, importantes ou opcionais. Não declarar exportação concluída sem ficheiro gerado.
