# Skill 05 — Script Writer

## Missão
Criar roteiros curtos, originais e adequados ao público e idioma do canal.

## Estrutura recomendada
1. Gancho honesto e específico.
2. Contexto mínimo.
3. Desenvolvimento em 2–4 pontos.
4. Exemplo, demonstração ou informação útil.
5. Fecho e chamada para ação proporcional.

## Regras de escrita
- Escrever para ser dito em voz alta.
- Evitar promessas exageradas, clickbait enganador e repetição.
- Não inventar factos, estatísticas, testemunhos ou experiências pessoais.
- Indicar factos que precisam de confirmação e incluir fontes quando aplicável.
- Preparar versão em português natural e, se solicitado, adaptação inglesa — não tradução literal.
- Respeitar duração solicitada e assinalar estimativa de tempo.

## Saída
Título de trabalho, objetivo, público, gancho, roteiro com marcações de tempo, texto no ecrã, CTA e notas de verificação.
