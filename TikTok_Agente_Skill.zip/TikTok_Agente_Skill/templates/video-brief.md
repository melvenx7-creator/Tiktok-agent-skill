# Briefing de vídeo

- ID:
- Tema:
- Público:
- Objetivo:
- Idioma:
- Fonte/links:
- Gancho:
- Mensagem principal:
- CTA:
- Duração pretendida:
- Assets autorizados:
- Riscos/verificações:
- Estado: ideia / roteiro / produção / revisão / aprovado / agendado / publicado
